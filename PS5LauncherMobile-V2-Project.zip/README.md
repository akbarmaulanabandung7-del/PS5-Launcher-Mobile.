# PS5 Launcher Mobile V2

Landscape launcher concept with horizontal app/game cards, local profiles, and a selectable looping video background.

Build through GitHub Actions. Download artifact `PS5-Launcher-Mobile-V2`, extract it, then install `app-debug.apk`.

Profiles are local launcher profiles, not PlayStation Network accounts. Android system UI such as the lock screen, notification shade and Settings remains controlled by Samsung/Android. The launcher requests landscape orientation; the phone panel itself may not be exactly 16:9.

package com.akbar.ps5launcher;

import android.app.*;
import android.os.*;
import android.content.*;
import android.content.pm.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.net.Uri;
import android.view.*;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    private FrameLayout stage;
    private VideoView video;
    private LinearLayout main, cards;
    private TextView profileButton, clock, subtitle;
    private SharedPreferences prefs;
    private String activeProfile = "Player";
    private static final int PICK_VIDEO = 71;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.TRANSPARENT);
        getWindow().setNavigationBarColor(Color.TRANSPARENT);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        prefs = getSharedPreferences("ps5launcher", MODE_PRIVATE);
        activeProfile = prefs.getString("active_profile", "Player");
        buildUi();
    }

    private GradientDrawable shape(int color, int radius) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(radius);
        d.setStroke(2, 0x55FFFFFF); return d;
    }
    private TextView label(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setGravity(Gravity.CENTER_VERTICAL); return t;
    }

    private void buildUi() {
        stage = new FrameLayout(this);
        stage.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{0xFF071A38,0xFF164C83,0xFF07152B}));
        setContentView(stage);
        video = new VideoView(this);
        stage.addView(video, new FrameLayout.LayoutParams(-1,-1));
        loadSavedVideo();

        View shade = new View(this);
        shade.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0x99030D20,0x44030D20,0xBB030B18}));
        stage.addView(shade, new FrameLayout.LayoutParams(-1,-1));

        main = new LinearLayout(this); main.setOrientation(LinearLayout.VERTICAL);
        main.setPadding(30,22,30,18);
        stage.addView(main, new FrameLayout.LayoutParams(-1,-1));

        LinearLayout top = new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL);
        TextView brand = label("◉  PLAYSTATION",22,Color.WHITE,true);
        top.addView(brand,new LinearLayout.LayoutParams(0,52,1));
        clock = label("",15,Color.WHITE,true); top.addView(clock);
        profileButton = label("   ◉  "+activeProfile+"   ▾   ",14,Color.WHITE,true);
        profileButton.setPadding(12,8,12,8); profileButton.setBackground(shape(0x663C6C9B,28));
        LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(-2,-2); pp.leftMargin=18;
        top.addView(profileButton,pp); profileButton.setOnClickListener(v->showProfiles());
        main.addView(top);

        LinearLayout nav=new LinearLayout(this); nav.setGravity(Gravity.CENTER_VERTICAL);
        String[] tabs={"Games","Media","Library","Settings"};
        for(int i=0;i<tabs.length;i++){
            final String selected=tabs[i];
            TextView tab=label(selected,15,i==0?Color.WHITE:0xFFB9D2EC,i==0);
            tab.setPadding(0,5,28,9); nav.addView(tab);
            tab.setOnClickListener(v->{
                if(selected.equals("Settings")) showSettings();
                else if(selected.equals("Library")||selected.equals("Games")) populateApps();
                else new AlertDialog.Builder(this).setMessage("Media akan ditambahkan pada pembaruan berikutnya.").setPositiveButton("OK",null).show();
            });
        }
        main.addView(nav);
        subtitle=label("Welcome back, "+activeProfile,14,0xFFD2E5FA,false); main.addView(subtitle);
        TextView title=label("Explore your games",27,Color.WHITE,true);
        title.setPadding(0,2,0,10); main.addView(title);

        HorizontalScrollView hsv=new HorizontalScrollView(this); hsv.setHorizontalScrollBarEnabled(false);
        cards=new LinearLayout(this); cards.setOrientation(LinearLayout.HORIZONTAL); hsv.addView(cards);
        main.addView(hsv,new LinearLayout.LayoutParams(-1,0,1));
        populateApps();

        LinearLayout bottom=new LinearLayout(this); bottom.setGravity(Gravity.CENTER_VERTICAL);
        TextView hint=label("✦  Select a game to start",12,0xFFD0E3F8,false);
        bottom.addView(hint,new LinearLayout.LayoutParams(0,38,1));
        TextView change=label("CHANGE VIDEO BACKGROUND  ↗",11,Color.WHITE,true);
        change.setPadding(14,9,14,9); change.setBackground(shape(0x664B79A8,24));
        bottom.addView(change); change.setOnClickListener(v->pickVideo());
        main.addView(bottom); updateClock();
    }

    private void updateClock(){
        clock.setText(new SimpleDateFormat("HH:mm   EEE, dd MMM",Locale.getDefault()).format(new Date()));
        clock.postDelayed(()->updateClock(),30000);
    }

    private void populateApps(){
        cards.removeAllViews();
        PackageManager pm=getPackageManager();
        List<ApplicationInfo> all=pm.getInstalledApplications(PackageManager.GET_META_DATA);
        ArrayList<ApplicationInfo> apps=new ArrayList<>();
        for(ApplicationInfo a:all) if(pm.getLaunchIntentForPackage(a.packageName)!=null && !a.packageName.equals(getPackageName())) apps.add(a);
        Collections.sort(apps,(a,b)->pm.getApplicationLabel(a).toString().compareToIgnoreCase(pm.getApplicationLabel(b).toString()));
        int[] colors={0xFF286AA5,0xFF392B70,0xFF176A7A,0xFF3B5578};
        int n=0;
        for(ApplicationInfo app:apps){
            LinearLayout tile=new LinearLayout(this); tile.setOrientation(LinearLayout.VERTICAL);
            tile.setPadding(9,9,9,8); tile.setBackground(shape(0xAA18385F,18));
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(205,-1); lp.rightMargin=12; cards.addView(tile,lp);
            FrameLayout artwork=new FrameLayout(this);
            artwork.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{colors[n%4],0xFF09172D}));
            tile.addView(artwork,new LinearLayout.LayoutParams(-1,0,1));
            ImageView icon=new ImageView(this);
            try{icon.setImageDrawable(pm.getApplicationIcon(app));}catch(Exception ignored){}
            artwork.addView(icon,new FrameLayout.LayoutParams(78,78,Gravity.CENTER));
            TextView name=label(pm.getApplicationLabel(app).toString(),13,Color.WHITE,true);
            name.setMaxLines(1); name.setPadding(4,9,4,2); tile.addView(name);
            tile.setOnClickListener(v->{Intent launch=pm.getLaunchIntentForPackage(app.packageName);if(launch!=null)startActivity(launch);});
            n++;
        }
    }

    private void showProfiles(){
        ArrayList<String> profiles=new ArrayList<>();
        String saved=prefs.getString("profiles","Player");
        for(String s:saved.split("\\|")) if(!s.trim().isEmpty()) profiles.add(s);
        String[] choices=new String[profiles.size()+1];
        for(int i=0;i<profiles.size();i++) choices[i]=profiles.get(i);
        choices[choices.length-1]="＋  Add new user";
        new AlertDialog.Builder(this).setTitle("Who's playing?").setItems(choices,(d,w)->{
            if(w==choices.length-1)addProfile();
            else{activeProfile=profiles.get(w);prefs.edit().putString("active_profile",activeProfile).apply();refreshProfile();}
        }).show();
    }

    private void addProfile(){
        EditText input=new EditText(this);input.setSingleLine(true);input.setHint("Enter profile name");
        new AlertDialog.Builder(this).setTitle("Create user").setMessage("Create a local launcher profile")
            .setView(input).setNegativeButton("Cancel",null).setPositiveButton("Create",(d,w)->{
                String name=input.getText().toString().trim();
                if(name.isEmpty())name="Player "+(System.currentTimeMillis()%1000);
                String old=prefs.getString("profiles","Player");
                if(!Arrays.asList(old.split("\\|")).contains(name))old=old+"|"+name;
                prefs.edit().putString("profiles",old).putString("active_profile",name).apply();
                activeProfile=name;refreshProfile();
            }).show();
    }
    private void refreshProfile(){
        profileButton.setText("   ◉  "+activeProfile+"   ▾   ");
        subtitle.setText("Welcome back, "+activeProfile);
    }

    private void showSettings(){
        String[] items={"Choose video background","Remove video background","Manage profiles","About"};
        new AlertDialog.Builder(this).setTitle("Settings").setItems(items,(d,w)->{
            if(w==0)pickVideo();
            else if(w==1){prefs.edit().remove("video_uri").apply();video.stopPlayback();video.setVisibility(View.GONE);}
            else if(w==2)showProfiles();
            else new AlertDialog.Builder(this).setMessage("PS5 Launcher Mobile V2\\nCommunity-made Android launcher concept.").setPositiveButton("OK",null).show();
        }).show();
    }
    private void pickVideo(){
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("video/*");startActivityForResult(i,PICK_VIDEO);
    }
    @Override protected void onActivityResult(int req,int res,Intent data){
        super.onActivityResult(req,res,data);
        if(req==PICK_VIDEO&&res==RESULT_OK&&data!=null&&data.getData()!=null){
            Uri uri=data.getData();
            try{getContentResolver().takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}
            prefs.edit().putString("video_uri",uri.toString()).apply();playVideo(uri);
        }
    }
    private void loadSavedVideo(){
        String s=prefs.getString("video_uri",null);
        if(s!=null)try{playVideo(Uri.parse(s));}catch(Exception ignored){}
    }
    private void playVideo(Uri uri){
        try{
            video.setVisibility(View.VISIBLE);video.setVideoURI(uri);
            video.setOnPreparedListener(mp->{mp.setLooping(true);mp.setVolume(0f,0f);video.start();});
            video.setOnErrorListener((mp,w,e)->{video.setVisibility(View.GONE);return true;});
        }catch(Exception e){video.setVisibility(View.GONE);}
    }
}

PS5 LAUNCHER V3 - PROJECT ANDROID
Target: Samsung Galaxy A14
Package: com.akbar.ps5launcher

Prototipe mencakup:
- Android Home launcher intent (pengguna memilihnya sebagai launcher default melalui Android)
- Setup nama profil
- UI landscape bergaya PS5 Blue, tema Midnight dan Cinematic
- Daftar aplikasi Android
- Tab Games, Media, Library, Settings
- Virtual pad bergaya DualSense (tombol overlay dasar)
- Input gamepad/keyboard untuk navigasi Android
- Pengaturan volume dan efek suara
- Pemilih video background (URI disimpan; pemutaran video belum terintegrasi di prototipe ini)

Catatan: Ini launcher Android bergaya PS5, bukan sistem operasi PS5. Tombol virtual prototipe belum menjadi kontrol sentuh analog penuh seperti emulator. Audio pihak ketiga hanya boleh digunakan sesuai izin/hak pemiliknya.

Build:
GitHub > Actions > Build PS5 Launcher V3 > Run workflow.
Unduh artifact PS5-Launcher-V3-APK.

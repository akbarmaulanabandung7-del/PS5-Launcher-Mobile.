package com.akbar.ps5launcher;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    private LinearLayout root, grid;
    private TextView clock, date;
    private int blue = Color.rgb(93,177,255);

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(5,15,32));
        getWindow().setNavigationBarColor(Color.rgb(5,15,32));
        build();
    }

    private GradientDrawable bg(int a, int b, int radius) {
        GradientDrawable d = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{a,b});
        d.setCornerRadius(radius);
        d.setStroke(1, Color.argb(45,255,255,255));
        return d;
    }

    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setGravity(Gravity.CENTER_VERTICAL);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private void build() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(20,22,20,24);
        root.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{Color.rgb(7,22,48),Color.rgb(13,48,91),Color.rgb(4,12,28)}));
        scroll.addView(root);
        setContentView(scroll);

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView logo = text("◉  PLAYSTATION",18,Color.WHITE,true);
        top.addView(logo,new LinearLayout.LayoutParams(0,55,1));
        LinearLayout timeBox = new LinearLayout(this);
        timeBox.setOrientation(LinearLayout.VERTICAL);
        timeBox.setGravity(Gravity.RIGHT);
        clock = text("",18,Color.WHITE,true);
        date = text("",11,0xFFB8D8F5,false);
        timeBox.addView(clock); timeBox.addView(date);
        top.addView(timeBox);
        root.addView(top);
        updateTime();

        TextView welcome = text("Selamat datang kembali",14,0xFFB7D8F5,false);
        welcome.setPadding(2,20,0,2); root.addView(welcome);
        TextView heading = text("Game Hub",30,Color.WHITE,true);
        root.addView(heading);
        TextView sub = text("Pilih game atau aplikasi untuk dibuka",13,0xFFB7D8F5,false);
        sub.setPadding(2,2,0,18); root.addView(sub);

        TextView featured = text("  ✦   YOUR GAMING SPACE",14,Color.WHITE,true);
        featured.setPadding(14,0,12,0);
        featured.setBackground(bg(0xFF174B83,0xFF102A50,22));
        root.addView(featured,new LinearLayout.LayoutParams(-1,58));

        TextView label = text("APLIKASI & GAME",14,0xFFB7D8F5,true);
        label.setPadding(2,24,0,12); root.addView(label);

        grid = new LinearLayout(this);
        grid.setOrientation(LinearLayout.VERTICAL);
        root.addView(grid);
        loadApps();

        TextView footer = text("PS5 Launcher Mobile  •  Versi 1.0",11,0xFF8EACCC,false);
        footer.setGravity(Gravity.CENTER);
        footer.setPadding(0,26,0,12); root.addView(footer);
    }

    private void updateTime() {
        Date now = new Date();
        clock.setText(new SimpleDateFormat("HH:mm", Locale.getDefault()).format(now));
        date.setText(new SimpleDateFormat("EEE, dd MMM yyyy", Locale.getDefault()).format(now));
        clock.postDelayed(() -> updateTime(), 30000);
    }

    private void loadApps() {
        PackageManager pm = getPackageManager();
        List<ApplicationInfo> apps = pm.getInstalledApplications(PackageManager.GET_META_DATA);
        ArrayList<ApplicationInfo> launchable = new ArrayList<>();
        for (ApplicationInfo a : apps) {
            if (pm.getLaunchIntentForPackage(a.packageName) != null &&
                !a.packageName.equals(getPackageName())) launchable.add(a);
        }
        Collections.sort(launchable, (a,b) ->
            pm.getApplicationLabel(a).toString().compareToIgnoreCase(pm.getApplicationLabel(b).toString()));

        int count = 0;
        LinearLayout row = null;
        for (ApplicationInfo app : launchable) {
            if (count % 3 == 0) {
                row = new LinearLayout(this);
                row.setGravity(Gravity.TOP);
                grid.addView(row,new LinearLayout.LayoutParams(-1,-2));
            }
            LinearLayout tile = new LinearLayout(this);
            tile.setOrientation(LinearLayout.VERTICAL);
            tile.setGravity(Gravity.CENTER);
            tile.setPadding(5,12,5,10);
            tile.setBackground(bg(0xCC17365D,0xCC0B1C36,20));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0,126,1);
            lp.setMargins(4,4,4,8);
            row.addView(tile,lp);

            ImageView icon = new ImageView(this);
            try { icon.setImageDrawable(pm.getApplicationIcon(app)); } catch(Exception ignored) {}
            tile.addView(icon,new LinearLayout.LayoutParams(54,54));
            TextView name = text(pm.getApplicationLabel(app).toString(),11,Color.WHITE,true);
            name.setGravity(Gravity.CENTER);
            name.setMaxLines(2);
            LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(-1,-2);
            np.topMargin=7; tile.addView(name,np);
            tile.setOnClickListener(v -> {
                Intent launch = pm.getLaunchIntentForPackage(app.packageName);
                if (launch != null) startActivity(launch);
            });
            count++;
        }
        if (count == 0) grid.addView(text("Tidak ada aplikasi yang ditemukan.",14,Color.WHITE,false));
    }
}

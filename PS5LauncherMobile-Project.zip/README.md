# PS5 Launcher Mobile

Starter Android launcher project for personal use.

## Build APK
1. Upload this project to a GitHub repository.
2. Open the repository's Actions tab.
3. Run **Build PS5 Launcher APK** (or push to `main`).
4. Download the `PS5-Launcher-Mobile` artifact from the completed workflow.
5. Extract the artifact ZIP to get `app-debug.apk`.
6. Install it, then press Home and choose **PS5 Launcher Mobile**.

The launcher displays installed launchable apps and opens them when tapped. Android system Settings, notification shade, lock screen and navigation controls remain Samsung/Android UI.
